# zhousidun_model > 2023-05-23 2:49am
https://universe.roboflow.com/shanghaitech-faxfj/zhousidun_model

Provided by a Roboflow user
License: CC BY 4.0

